Installation
  Code Edit makes no system changes. Just extract all the 
  files in codeedit.zip to the directory in which you want 
  Code Edit to be (perhaps C:\Program Files\Code Edit). 

What Code Edit comes with
  - CodeEdit.exe
  - codeedit.hlp
  - readme.txt
  * ce1512.ini (created and maintained by Code Edit)

Uninstallation
  Since Code Edit makes no system changes, all you have to do 
  is delete all the files with which Code Edit comes or which 
  Code Edit creates.

Distrubution
  Code Edit may be redistributed freely--even with other 
  software.